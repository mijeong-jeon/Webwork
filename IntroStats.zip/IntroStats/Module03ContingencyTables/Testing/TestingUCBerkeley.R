# UC Berkeley
MyData = read.csv("../../Module03_Datasets/BerkeleyAdmissions.csv")
table(MyData$Sex, MyData$Department)
